// Create grid
function makeGrid() {
  $("#canvas").html("");
  var height = $("#rowHeight").val();
  var width = $("#rowWidth").val();
  for (x = 0; x < height; x++) {
    $("#canvas").append("<tr></tr>");
    for (y = 0; y < width; y++) {
      $("#canvas")
        .children()
        .last()
        .append("<td></td>");
    }
  }
}

// Call makeGrid function after clicking submit.
$("form#gridSize").on("submit", function(event) {
  event.preventDefault();
  makeGrid();
});

// Color selected cell with picked color when it is clicked on.
$("#canvas").on("click", "td", function() {
  $(this).css("background-color", $("#color").val());
});
